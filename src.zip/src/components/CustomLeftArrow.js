import React, { Component } from 'react'

export class CustomLeftArrow extends Component {
    render() {
        return (
            <div>
               <span style={{height:30,width:30,backgroundColor:"yellow", borderRadius:"50%",display:"inline-block"}} >
               --
               
               </span>
            </div>
        )
    }
}

export default CustomLeftArrow
